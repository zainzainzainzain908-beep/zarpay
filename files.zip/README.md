# Zarpay

A wallet app with a real backend: double-entry ledger, server-held balances, idempotent
transfers, PIN re-authorisation and reversals. Pakistani rails in mind (Raast IDs, PKR,
mobile top-ups, utility bills).

No npm packages. The database is SQLite, built into Node.

## Run it

You need **Node 22.5 or newer** (`node -v` to check; Node 22 LTS or 24 both work).

```bash
cd zarpay
npm start          # or: node --disable-warning=ExperimentalWarning server.js
```

Open <http://localhost:4000>. Create a wallet with any 03XX number and a 4-digit PIN.
Open a second browser profile, register a second number, and send money between them.

A new wallet starts at Rs 0 — use **Add money** first. That posts against the bank
settlement account, which is what a card top-up or an IBFT pull-in would do in real life.

Check the books at any time:

```bash
curl localhost:4000/api/ledger/proof
```

It returns `balanced: true` only if every transfer's debits equal its credits and the
net across all accounts is exactly zero.

Opening `public/index.html` directly as a file (no server) drops the app into a local
demo mode with fake data. Useful for design work, useless for anything else.

## How the money model works

Balances are **never stored**. A balance is `SUM(credits) - SUM(debits)` over the
`entries` table for that account, so it cannot silently drift.

Every amount is an **integer in paisa**. Floating point does not belong anywhere near money.

Sending Rs 3,000 with a Rs 3 fee writes three rows in one transaction:

| account | direction | paisa |
|---|---|---|
| sender wallet | debit | 300300 |
| recipient wallet | credit | 300000 |
| fee income | credit | 300 |

Debits and credits sum to zero. If they don't, the write is rejected before commit.

Money entering or leaving the system always has a system account on the other side:
`sys_settlement` (bank/card rails), `sys_fees`, `sys_billers`, `sys_telco`. A negative
settlement balance means that much customer money is sitting with the bank — which is
exactly the trust-account position SBP requires an EMI to safeguard.

Other things it gets right:

- **Idempotency.** Pass `idempotency_key`. A retry returns the original transfer with
  `replayed: true` instead of moving money twice. The app generates one key per payment
  attempt and reuses it if the PIN was wrong.
- **Concurrency.** Balance checks happen inside `BEGIN IMMEDIATE`, so two simultaneous
  transfers cannot both pass the same check and overdraw.
- **Reversals.** Nothing is deleted. A reversal posts the mirror image of the original
  entries and flips the original's status to `reversed`. The audit trail stays intact.
- **PINs.** Hashed with scrypt, per-user salt, compared in constant time, never sent to
  the client. Five wrong attempts locks the wallet for 15 minutes.
- **Limits.** Rs 500,000 per transaction, Rs 500,000 wallet ceiling, Rs 400,000 loaded
  per month. Change them at the top of `server.js`.

## API

All money endpoints require `Authorization: Bearer <token>` *and* the PIN in the body.

| Endpoint | Purpose |
|---|---|
| `POST /api/auth/register` | `{phone, name, pin}` → token. Creates user + wallet account. |
| `POST /api/auth/login` | `{phone, pin}` → token |
| `POST /api/auth/logout` | Drops the session |
| `GET /api/me` | User, balance, monthly load usage |
| `GET /api/directory` | Other registered wallets |
| `GET /api/transactions?limit=50` | This wallet's ledger view |
| `POST /api/transfers` | `{to_phone, amount_paisa, note, pin, idempotency_key}` |
| `POST /api/topups` | `{source, amount_paisa, pin, idempotency_key}` |
| `POST /api/bills` | `{biller, consumer, amount_paisa, pin, idempotency_key}` |
| `POST /api/loads` | `{msisdn, network, amount_paisa, pin, idempotency_key}` |
| `POST /api/transfers/reverse` | `{transfer_id, pin}` |
| `GET /api/ledger/proof` | Integrity check for a cron job |

Errors come back as `{error: {code, message}}` with a sensible HTTP status —
`insufficient_funds` is 402, `locked` is 423, `rate_limited` is 429.

## What is still missing before this touches real money

The ledger is the part most people get wrong, and it's done. These are not:

1. **A licence.** Holding customer balances in Pakistan requires an SBP Electronic Money
   Institution licence: an SECP-registered company, PKR 200 million paid-up capital, and
   three stages (in-principle → pilot → commercial). Individuals cannot apply. The usual
   shortcut is to build the front end and let a licensed EMI or bank hold the funds.
2. **Real rails.** `sys_settlement` is currently a bookkeeping fiction. Real money means
   1LINK / Raast P2M for collections and IBFT for payouts, each with its own settlement
   file to reconcile against your ledger every single day.
3. **Two-phase settlement.** A top-up here settles instantly. In reality you post it
   `pending`, wait for the acquirer's webhook, then settle or fail. The `status` column
   is already there for it.
4. **Identity.** Phone OTP at registration, CNIC capture, NADRA Verisys, liveness check,
   sanctions screening, and transaction monitoring for AML/CFT reporting.
5. **Operational hardening.** Postgres instead of SQLite once you have concurrency,
   TLS everywhere, secrets outside the repo, Redis-backed rate limiting (the current one
   is in-memory and resets on restart), structured logs with no PII, per-device session
   binding, and an append-only audit store the application user cannot write over.
6. **Reconciliation.** Run `/api/ledger/proof` on a schedule and page someone when it
   returns false. Also reconcile your ledger totals against the bank's statement daily.

Build (2) and (3) against a gateway sandbox — PayFast, Safepay or 1LINK's 1GO — before
you approach anyone about (1). Being able to demo real Raast movement changes the
conversation.
