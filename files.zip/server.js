/**
 * Zarpay backend — a real wallet ledger.
 *
 * Zero dependencies. Uses node:sqlite (built into Node 22.5+).
 *   node --disable-warning=ExperimentalWarning server.js
 *
 * Design notes that matter for money:
 *  - Every amount is an INTEGER in paisa. Never a float. 1 PKR = 100 paisa.
 *  - Every movement is double-entry: debits and credits must sum to zero
 *    inside one transfer, enforced before COMMIT.
 *  - A balance is never stored. It is derived from the entries table, so it
 *    cannot drift away from the ledger.
 *  - Every write goes through BEGIN IMMEDIATE so two concurrent transfers
 *    cannot both pass the same balance check.
 *  - Idempotency keys make a retried request return the original transfer
 *    instead of moving money twice.
 */

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 4000);
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'zarpay.db');
const PUBLIC_DIR = path.join(__dirname, 'public');

const MAX_TRANSFER_PAISA = 50_000_000;      // Rs 500,000 per transaction
const MAX_BALANCE_PAISA = 50_000_000;       // Rs 500,000 wallet ceiling
const MONTHLY_LOAD_LIMIT_PAISA = 40_000_000; // Rs 400,000 loaded per month
const SESSION_TTL_MS = 1000 * 60 * 60 * 12;
const MAX_PIN_ATTEMPTS = 5;
const LOCKOUT_MS = 1000 * 60 * 15;

/* ------------------------------------------------------------------ *
 * Schema
 * ------------------------------------------------------------------ */

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  phone         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  pin_hash      TEXT NOT NULL,
  pin_salt      TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'active',
  failed_pins   INTEGER NOT NULL DEFAULT 0,
  locked_until  INTEGER NOT NULL DEFAULT 0,
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS accounts (
  id         TEXT PRIMARY KEY,
  kind       TEXT NOT NULL,          -- wallet | settlement | fee_income | biller | telco
  user_id    TEXT REFERENCES users(id),
  label      TEXT NOT NULL,
  currency   TEXT NOT NULL DEFAULT 'PKR',
  created_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_accounts_user ON accounts(user_id) WHERE user_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS transfers (
  id               TEXT PRIMARY KEY,
  kind             TEXT NOT NULL,     -- p2p | topup | bill | load | reversal
  status           TEXT NOT NULL,     -- pending | settled | reversed | failed
  amount_paisa     INTEGER NOT NULL CHECK (amount_paisa > 0),
  fee_paisa        INTEGER NOT NULL DEFAULT 0 CHECK (fee_paisa >= 0),
  initiator_id     TEXT REFERENCES users(id),
  counterparty     TEXT,
  reference        TEXT NOT NULL,
  note             TEXT,
  metadata         TEXT,
  idempotency_key  TEXT UNIQUE,
  reverses_id      TEXT REFERENCES transfers(id),
  created_at       INTEGER NOT NULL,
  settled_at       INTEGER
);
CREATE INDEX IF NOT EXISTS idx_transfers_initiator ON transfers(initiator_id, created_at DESC);

CREATE TABLE IF NOT EXISTS entries (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  transfer_id  TEXT NOT NULL REFERENCES transfers(id),
  account_id   TEXT NOT NULL REFERENCES accounts(id),
  direction    TEXT NOT NULL CHECK (direction IN ('debit','credit')),
  amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0),
  created_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entries_account ON entries(account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_entries_transfer ON entries(transfer_id);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  ts      INTEGER NOT NULL,
  actor   TEXT,
  action  TEXT NOT NULL,
  detail  TEXT
);
`);

/* ------------------------------------------------------------------ *
 * Small helpers
 * ------------------------------------------------------------------ */

const now = () => Date.now();
const id = (p) => p + '_' + crypto.randomBytes(9).toString('base64url');
const ref = () => 'ZP-' + Array.from(crypto.randomBytes(6))
  .map(b => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 32]).join('');

function audit(actor, action, detail) {
  db.prepare('INSERT INTO audit_log (ts,actor,action,detail) VALUES (?,?,?,?)')
    .run(now(), actor ?? null, action, detail ? JSON.stringify(detail) : null);
}

function hashPin(pin, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(String(pin), salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  return { hash, salt };
}
function verifyPin(pin, hash, salt) {
  const candidate = crypto.scryptSync(String(pin), salt, 64, { N: 16384, r: 8, p: 1 });
  const known = Buffer.from(hash, 'hex');
  return candidate.length === known.length && crypto.timingSafeEqual(candidate, known);
}

const normPhone = p => String(p || '').replace(/\D/g, '');
const validPhone = p => /^03\d{9}$/.test(normPhone(p));
const validPin = p => /^\d{4}$/.test(String(p || ''));

/* system accounts: the other side of every external movement */
function systemAccount(id_, kind, label) {
  const row = db.prepare('SELECT id FROM accounts WHERE id = ?').get(id_);
  if (!row) {
    db.prepare('INSERT INTO accounts (id,kind,user_id,label,currency,created_at) VALUES (?,?,NULL,?,?,?)')
      .run(id_, kind, label, 'PKR', now());
  }
  return id_;
}
const ACC_SETTLEMENT = systemAccount('sys_settlement', 'settlement', 'Bank settlement');
const ACC_FEES       = systemAccount('sys_fees', 'fee_income', 'Fee income');
const ACC_BILLERS    = systemAccount('sys_billers', 'biller', 'Biller payouts');
const ACC_TELCO      = systemAccount('sys_telco', 'telco', 'Telco payouts');

/* ------------------------------------------------------------------ *
 * Ledger
 * ------------------------------------------------------------------ */

function balanceOf(accountId) {
  const r = db.prepare(`
    SELECT COALESCE(SUM(CASE WHEN direction='credit' THEN amount_paisa ELSE -amount_paisa END), 0) AS bal
    FROM entries WHERE account_id = ?`).get(accountId);
  return Number(r.bal);
}

function walletOf(userId) {
  return db.prepare('SELECT id FROM accounts WHERE user_id = ?').get(userId)?.id;
}

function monthlyLoaded(userId) {
  const start = new Date(); start.setDate(1); start.setHours(0, 0, 0, 0);
  const r = db.prepare(`
    SELECT COALESCE(SUM(amount_paisa),0) AS s FROM transfers
    WHERE initiator_id = ? AND kind = 'topup' AND status = 'settled' AND created_at >= ?`)
    .get(userId, start.getTime());
  return Number(r.s);
}

class LedgerError extends Error {
  constructor(code, message, status = 400) { super(message); this.code = code; this.status = status; }
}

/**
 * Post one balanced transfer. `legs` is a list of {account, direction, amount}.
 * Everything happens inside one immediate transaction.
 */
function postTransfer({ kind, legs, amount, fee = 0, initiator, counterparty, reference, note, metadata, idempotencyKey }) {
  if (idempotencyKey) {
    const existing = db.prepare('SELECT * FROM transfers WHERE idempotency_key = ?').get(idempotencyKey);
    if (existing) return { transfer: existing, replayed: true };
  }

  const debits = legs.filter(l => l.direction === 'debit').reduce((a, l) => a + l.amount, 0);
  const credits = legs.filter(l => l.direction === 'credit').reduce((a, l) => a + l.amount, 0);
  if (debits !== credits) throw new LedgerError('unbalanced', 'Ledger entries do not balance', 500);
  if (legs.some(l => !Number.isSafeInteger(l.amount) || l.amount <= 0)) {
    throw new LedgerError('bad_amount', 'Every entry must be a positive whole number of paisa');
  }

  const tid = id('txf');
  const ts = now();

  db.exec('BEGIN IMMEDIATE');
  try {
    // Balance checks happen inside the transaction, against the live ledger.
    for (const leg of legs) {
      const acc = db.prepare('SELECT kind FROM accounts WHERE id = ?').get(leg.account);
      if (!acc) throw new LedgerError('no_account', 'Account not found', 404);
      if (acc.kind !== 'wallet') continue;
      const bal = balanceOf(leg.account);
      if (leg.direction === 'debit' && bal < leg.amount) {
        throw new LedgerError('insufficient_funds', 'Not enough balance', 402);
      }
      if (leg.direction === 'credit' && bal + leg.amount > MAX_BALANCE_PAISA) {
        throw new LedgerError('balance_limit', 'This would push the wallet over its limit', 409);
      }
    }

    db.prepare(`INSERT INTO transfers
      (id,kind,status,amount_paisa,fee_paisa,initiator_id,counterparty,reference,note,metadata,idempotency_key,created_at,settled_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(tid, kind, 'settled', amount, fee, initiator ?? null, counterparty ?? null,
           reference, note ?? null, metadata ? JSON.stringify(metadata) : null,
           idempotencyKey ?? null, ts, ts);

    const ins = db.prepare('INSERT INTO entries (transfer_id,account_id,direction,amount_paisa,created_at) VALUES (?,?,?,?,?)');
    for (const leg of legs) ins.run(tid, leg.account, leg.direction, leg.amount, ts);

    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE' && idempotencyKey) {
      const existing = db.prepare('SELECT * FROM transfers WHERE idempotency_key = ?').get(idempotencyKey);
      if (existing) return { transfer: existing, replayed: true };
    }
    throw err;
  }

  audit(initiator, 'transfer.settled', { id: tid, kind, amount, fee });
  return { transfer: db.prepare('SELECT * FROM transfers WHERE id = ?').get(tid), replayed: false };
}

/** Reverse a settled transfer by posting the mirror image of its entries. */
function reverseTransfer(transferId, actor) {
  const orig = db.prepare('SELECT * FROM transfers WHERE id = ?').get(transferId);
  if (!orig) throw new LedgerError('not_found', 'Transfer not found', 404);
  if (orig.status !== 'settled') throw new LedgerError('bad_state', `Cannot reverse a ${orig.status} transfer`, 409);

  const legs = db.prepare('SELECT account_id, direction, amount_paisa FROM entries WHERE transfer_id = ?')
    .all(transferId)
    .map(e => ({ account: e.account_id, direction: e.direction === 'debit' ? 'credit' : 'debit', amount: Number(e.amount_paisa) }));

  const { transfer } = postTransfer({
    kind: 'reversal', legs,
    amount: Number(orig.amount_paisa), fee: 0,
    initiator: orig.initiator_id, counterparty: orig.counterparty,
    reference: ref(), note: `Reversal of ${orig.reference}`,
    metadata: { reverses: transferId },
    idempotencyKey: 'rev_' + transferId
  });

  db.prepare('UPDATE transfers SET status = ?, reverses_id = ? WHERE id = ?').run('reversed', transfer.id, transferId);
  audit(actor, 'transfer.reversed', { original: transferId, reversal: transfer.id });
  return transfer;
}

/* Fee policy — one place, so it can be audited and changed. */
function feeFor(kind, amountPaisa, sameWallet) {
  if (kind !== 'p2p') return 0;
  if (sameWallet) return 0;
  return amountPaisa > 2_500_000 ? Math.round(amountPaisa * 0.001) : 0;
}

/* ------------------------------------------------------------------ *
 * HTTP plumbing
 * ------------------------------------------------------------------ */

function send(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff'
  });
  res.end(payload);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '', size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > 64 * 1024) { reject(new LedgerError('too_large', 'Body too large', 413)); req.destroy(); return; }
      raw += c;
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(new LedgerError('bad_json', 'Body is not valid JSON')); }
    });
    req.on('error', reject);
  });
}

const attempts = new Map(); // crude in-memory rate limit; use Redis in production
function rateLimit(key, max, windowMs) {
  const rec = attempts.get(key) || { n: 0, reset: now() + windowMs };
  if (now() > rec.reset) { rec.n = 0; rec.reset = now() + windowMs; }
  rec.n += 1;
  attempts.set(key, rec);
  if (rec.n > max) throw new LedgerError('rate_limited', 'Too many attempts. Wait a few minutes.', 429);
}

function authenticate(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) throw new LedgerError('unauthenticated', 'Sign in first', 401);
  const s = db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
  if (!s || s.expires_at < now()) throw new LedgerError('unauthenticated', 'Session expired', 401);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(s.user_id);
  if (!user || user.status !== 'active') throw new LedgerError('unauthenticated', 'Account unavailable', 401);
  return user;
}

/** Re-check the PIN for anything that moves money. */
function requirePin(user, pin) {
  if (user.locked_until > now()) throw new LedgerError('locked', 'Too many wrong PINs. Try again later.', 423);
  if (!verifyPin(pin, user.pin_hash, user.pin_salt)) {
    const failed = user.failed_pins + 1;
    const lock = failed >= MAX_PIN_ATTEMPTS ? now() + LOCKOUT_MS : 0;
    db.prepare('UPDATE users SET failed_pins = ?, locked_until = ? WHERE id = ?').run(failed, lock, user.id);
    audit(user.id, 'pin.failed', { failed });
    throw new LedgerError('bad_pin', 'Incorrect PIN', 401);
  }
  if (user.failed_pins) db.prepare('UPDATE users SET failed_pins = 0, locked_until = 0 WHERE id = ?').run(user.id);
}

function publicUser(u) {
  const wallet = walletOf(u.id);
  return {
    id: u.id, name: u.name, phone: u.phone,
    iban: 'PK36ZARP' + u.phone.slice(-12).padStart(16, '0'),
    balance_paisa: balanceOf(wallet),
    monthly_loaded_paisa: monthlyLoaded(u.id),
    monthly_load_limit_paisa: MONTHLY_LOAD_LIMIT_PAISA
  };
}

function txView(t, userId) {
  const wallet = walletOf(userId);
  const legs = db.prepare('SELECT account_id, direction, amount_paisa FROM entries WHERE transfer_id = ?').all(t.id);
  const mine = legs.filter(l => l.account_id === wallet);
  const net = mine.reduce((a, l) => a + (l.direction === 'credit' ? Number(l.amount_paisa) : -Number(l.amount_paisa)), 0);
  return {
    id: t.id, reference: t.reference, kind: t.kind, status: t.status,
    direction: net >= 0 ? 'in' : 'out',
    amount_paisa: Math.abs(net) || Number(t.amount_paisa),
    fee_paisa: Number(t.fee_paisa),
    counterparty: t.counterparty, note: t.note,
    metadata: t.metadata ? JSON.parse(t.metadata) : null,
    created_at: t.created_at, settled_at: t.settled_at
  };
}

/* ------------------------------------------------------------------ *
 * Routes
 * ------------------------------------------------------------------ */

const routes = {
  'GET /api/health': async () => ({ ok: true, service: 'zarpay', time: now() }),

  'POST /api/auth/register': async (req, res, body, ip) => {
    rateLimit('reg:' + ip, 10, 60_000);
    const phone = normPhone(body.phone);
    const name = String(body.name || '').trim();
    if (!validPhone(phone)) throw new LedgerError('bad_phone', 'Use an 11-digit number starting 03');
    if (name.length < 2) throw new LedgerError('bad_name', 'Enter your name');
    if (!validPin(body.pin)) throw new LedgerError('bad_pin', 'PIN must be 4 digits');
    if (db.prepare('SELECT 1 FROM users WHERE phone = ?').get(phone)) {
      throw new LedgerError('exists', 'That number is already registered', 409);
    }
    const { hash, salt } = hashPin(body.pin);
    const uid = id('usr');
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare('INSERT INTO users (id,phone,name,pin_hash,pin_salt,status,failed_pins,locked_until,created_at) VALUES (?,?,?,?,?,?,0,0,?)')
        .run(uid, phone, name, hash, salt, 'active', now());
      db.prepare('INSERT INTO accounts (id,kind,user_id,label,currency,created_at) VALUES (?,?,?,?,?,?)')
        .run(id('acc'), 'wallet', uid, name + ' wallet', 'PKR', now());
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    audit(uid, 'user.registered', { phone });
    return issueSession(uid);
  },

  'POST /api/auth/login': async (req, res, body, ip) => {
    rateLimit('login:' + ip, 20, 60_000);
    const phone = normPhone(body.phone);
    const user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
    // Same error either way, so this cannot be used to enumerate numbers.
    if (!user) { hashPin(body.pin || '0000'); throw new LedgerError('bad_credentials', 'Wrong number or PIN', 401); }
    try { requirePin(user, body.pin); }
    catch (e) { throw e.code === 'bad_pin' ? new LedgerError('bad_credentials', 'Wrong number or PIN', 401) : e; }
    audit(user.id, 'user.login', null);
    return issueSession(user.id);
  },

  'POST /api/auth/logout': async (req) => {
    const h = req.headers.authorization || '';
    if (h.startsWith('Bearer ')) db.prepare('DELETE FROM sessions WHERE token = ?').run(h.slice(7));
    return { ok: true };
  },

  'GET /api/me': async (req) => ({ user: publicUser(authenticate(req)) }),

  'GET /api/directory': async (req) => {
    const me = authenticate(req);
    const rows = db.prepare('SELECT id,name,phone FROM users WHERE id != ? AND status = ? ORDER BY created_at DESC LIMIT 50')
      .all(me.id, 'active');
    return { users: rows };
  },

  'GET /api/transactions': async (req, res, body, ip, url) => {
    const me = authenticate(req);
    const wallet = walletOf(me.id);
    const limit = Math.min(200, Number(url.searchParams.get('limit') || 50));
    const rows = db.prepare(`
      SELECT DISTINCT t.* FROM transfers t
      JOIN entries e ON e.transfer_id = t.id
      WHERE e.account_id = ?
      ORDER BY t.created_at DESC LIMIT ?`).all(wallet, limit);
    return { transactions: rows.map(t => txView(t, me.id)) };
  },

  'POST /api/transfers': async (req, res, body) => {
    const me = authenticate(req);
    requirePin(me, body.pin);

    const amount = Math.trunc(Number(body.amount_paisa));
    if (!Number.isSafeInteger(amount) || amount <= 0) throw new LedgerError('bad_amount', 'Enter an amount');
    if (amount > MAX_TRANSFER_PAISA) throw new LedgerError('limit', 'Over the per-transaction limit', 409);

    const toPhone = normPhone(body.to_phone);
    if (!validPhone(toPhone)) throw new LedgerError('bad_phone', 'Check the recipient number');
    if (toPhone === me.phone) throw new LedgerError('self_transfer', 'You cannot send money to yourself');

    const payee = db.prepare('SELECT * FROM users WHERE phone = ? AND status = ?').get(toPhone, 'active');
    const myWallet = walletOf(me.id);
    const fee = feeFor('p2p', amount, !!payee);

    // Registered payee -> internal wallet. Otherwise it leaves via settlement (Raast/IBFT).
    const creditAccount = payee ? walletOf(payee.id) : ACC_SETTLEMENT;
    const legs = [
      { account: myWallet, direction: 'debit', amount: amount + fee },
      { account: creditAccount, direction: 'credit', amount }
    ];
    if (fee > 0) legs.push({ account: ACC_FEES, direction: 'credit', amount: fee });

    const { transfer, replayed } = postTransfer({
      kind: 'p2p', legs, amount, fee,
      initiator: me.id,
      counterparty: payee ? payee.name : toPhone,
      reference: ref(),
      note: body.note ? String(body.note).slice(0, 80) : null,
      metadata: { to_phone: toPhone, rail: payee ? 'internal' : 'raast' },
      idempotencyKey: body.idempotency_key || null
    });
    return { transfer: txView(transfer, me.id), replayed, user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(me.id)) };
  },

  'POST /api/topups': async (req, res, body) => {
    const me = authenticate(req);
    requirePin(me, body.pin);
    const amount = Math.trunc(Number(body.amount_paisa));
    if (!Number.isSafeInteger(amount) || amount <= 0) throw new LedgerError('bad_amount', 'Enter an amount');
    if (monthlyLoaded(me.id) + amount > MONTHLY_LOAD_LIMIT_PAISA) {
      throw new LedgerError('load_limit', 'That is over your monthly load limit', 409);
    }
    // Real life: this leg only posts after the acquirer confirms. See README.
    const { transfer, replayed } = postTransfer({
      kind: 'topup',
      legs: [
        { account: ACC_SETTLEMENT, direction: 'debit', amount },
        { account: walletOf(me.id), direction: 'credit', amount }
      ],
      amount, fee: 0, initiator: me.id,
      counterparty: String(body.source || 'Linked account').slice(0, 60),
      reference: ref(), metadata: { source: body.source },
      idempotencyKey: body.idempotency_key || null
    });
    return { transfer: txView(transfer, me.id), replayed, user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(me.id)) };
  },

  'POST /api/bills': async (req, res, body) => {
    const me = authenticate(req);
    requirePin(me, body.pin);
    const amount = Math.trunc(Number(body.amount_paisa));
    if (!Number.isSafeInteger(amount) || amount <= 0) throw new LedgerError('bad_amount', 'Enter an amount');
    const biller = String(body.biller || '').slice(0, 60);
    const consumer = String(body.consumer || '').slice(0, 40);
    if (!biller || !consumer) throw new LedgerError('bad_bill', 'Biller and consumer number are required');

    const { transfer, replayed } = postTransfer({
      kind: 'bill',
      legs: [
        { account: walletOf(me.id), direction: 'debit', amount },
        { account: ACC_BILLERS, direction: 'credit', amount }
      ],
      amount, fee: 0, initiator: me.id, counterparty: biller,
      reference: ref(), metadata: { biller, consumer },
      idempotencyKey: body.idempotency_key || null
    });
    return { transfer: txView(transfer, me.id), replayed, user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(me.id)) };
  },

  'POST /api/loads': async (req, res, body) => {
    const me = authenticate(req);
    requirePin(me, body.pin);
    const amount = Math.trunc(Number(body.amount_paisa));
    if (!Number.isSafeInteger(amount) || amount <= 0) throw new LedgerError('bad_amount', 'Enter an amount');
    const msisdn = normPhone(body.msisdn);
    if (!validPhone(msisdn)) throw new LedgerError('bad_phone', 'Check the mobile number');

    const { transfer, replayed } = postTransfer({
      kind: 'load',
      legs: [
        { account: walletOf(me.id), direction: 'debit', amount },
        { account: ACC_TELCO, direction: 'credit', amount }
      ],
      amount, fee: 0, initiator: me.id,
      counterparty: String(body.network || 'Top-up').slice(0, 40),
      reference: ref(), metadata: { msisdn, network: body.network },
      idempotencyKey: body.idempotency_key || null
    });
    return { transfer: txView(transfer, me.id), replayed, user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(me.id)) };
  },

  'POST /api/transfers/reverse': async (req, res, body) => {
    const me = authenticate(req);
    requirePin(me, body.pin);
    const t = db.prepare('SELECT * FROM transfers WHERE id = ? OR reference = ?').get(body.transfer_id, body.transfer_id);
    if (!t) throw new LedgerError('not_found', 'Transfer not found', 404);
    if (t.initiator_id !== me.id) throw new LedgerError('forbidden', 'Not your transfer', 403);
    const rev = reverseTransfer(t.id, me.id);
    return { reversal: txView(rev, me.id), user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(me.id)) };
  },

  /* Operational endpoint: proves the books balance. Run it in a cron. */
  'GET /api/ledger/proof': async () => {
    const bad = db.prepare(`
      SELECT transfer_id,
             SUM(CASE WHEN direction='debit' THEN amount_paisa ELSE 0 END) AS d,
             SUM(CASE WHEN direction='credit' THEN amount_paisa ELSE 0 END) AS c
      FROM entries GROUP BY transfer_id HAVING d != c`).all();
    const total = db.prepare(`
      SELECT COALESCE(SUM(CASE WHEN direction='credit' THEN amount_paisa ELSE -amount_paisa END),0) AS net FROM entries`).get();
    const accounts = db.prepare('SELECT id,kind,label FROM accounts').all()
      .map(a => ({ ...a, balance_paisa: balanceOf(a.id) }));
    return { balanced: bad.length === 0 && Number(total.net) === 0, unbalanced_transfers: bad, net_across_all_accounts: Number(total.net), accounts };
  }
};

function issueSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions (token,user_id,created_at,expires_at) VALUES (?,?,?,?)')
    .run(token, userId, now(), now() + SESSION_TTL_MS);
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now());
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  return { token, user: publicUser(u) };
}

/* ------------------------------------------------------------------ *
 * Static files + dispatch
 * ------------------------------------------------------------------ */

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  const file = path.join(PUBLIC_DIR, path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403).end('Forbidden'); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'content-type': 'text/plain' }).end('Not found'); return; }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const key = `${req.method} ${url.pathname}`;
  const ip = req.socket.remoteAddress || 'local';

  if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);

  const handler = routes[key];
  if (!handler) return send(res, 404, { error: { code: 'no_route', message: 'Unknown endpoint' } });

  try {
    const body = req.method === 'GET' ? {} : await readBody(req);
    const out = await handler(req, res, body, ip, url);
    send(res, 200, out);
  } catch (err) {
    if (err instanceof LedgerError) return send(res, err.status, { error: { code: err.code, message: err.message } });
    console.error('[zarpay]', err);
    send(res, 500, { error: { code: 'internal', message: 'Something went wrong' } });
  }
});

server.listen(PORT, () => {
  console.log(`\n  Zarpay ledger running:  http://localhost:${PORT}`);
  console.log(`  Database:               ${DB_PATH}`);
  console.log(`  Books proof:            http://localhost:${PORT}/api/ledger/proof\n`);
});
