# 💳 Zarpay Admin Dashboard

Professional admin control panel for your Zarpay wallet backend. Monitor accounts, transactions, ledger, and system health—all in one place.

## ✨ Features

- 📊 **Real-time Dashboard** - System stats, health monitoring, uptime
- 💸 **Transaction Viewer** - Browse all transactions with details
- 👥 **Account Management** - Create, view, and delete user accounts
- 📖 **Ledger Proof** - Verify double-entry ledger integrity
- ⚙️ **Feature Controls** - Enable/disable app features (extensible)
- 🔐 **Secure Authentication** - Password-protected admin panel
- 🎨 **Beautiful Dark UI** - Professional, responsive design

## 🚀 Local Setup (2 minutes)

### Prerequisites
- Node.js 22.5.0+
- Your Zarpay backend running at `http://localhost:4000`

### Installation

```bash
# Copy files to your project
cp admin-server.js your-project/
cp package.json your-project/admin-package.json  # or rename
cp .env.example your-project/.env
```

### Run It

```bash
cd your-project
node admin-server.js
```

Visit: **http://localhost:3000**

Login with default password: **`changeme123`** (⚠️ change this!)

## 🌐 Deploy to Cloud (Free)

### Railway.app (Recommended)
1. Push to GitHub
2. Connect repo to Railway
3. Set environment variables:
   ```
   ADMIN_PASSWORD=your_password
   BACKEND_URL=https://your-backend.railway.app
   ```
4. Done! Auto-deployed

[Railway deployment guide →](./DEPLOYMENT.md#-deploy-to-railwayapp)

### Render.com
1. Create new Web Service from GitHub
2. Build: `npm install`
3. Start: `node admin-server.js`
4. Set same env vars as above

[Render deployment guide →](./DEPLOYMENT.md#-deploy-to-rendercom)

## 📋 Environment Variables

```env
# Required
ADMIN_PASSWORD=your_secure_password
BACKEND_URL=http://localhost:4000

# Optional
PORT=3000
```

Create a `.env` file or set them before running:

```bash
ADMIN_PASSWORD=mysecurepass BACKEND_URL=http://localhost:4000 node admin-server.js
```

## 🎯 Dashboard Walkthrough

### Dashboard Tab
- **Total Accounts** - Count of active user accounts
- **Total Transactions** - All transactions processed
- **Total Volume** - Sum of all balances (PKR)
- **System Health** - Backend connectivity status

### Transactions Tab
- View all transactions in real-time
- See: ID, From, To, Amount, Timestamp
- Latest 50 transactions displayed
- Sorted by most recent first

### Accounts Tab
- **Create Account** - Add new user with initial balance
  - Enter User ID (e.g., `user123`)
  - Set account name
  - Set initial balance
- **View Accounts** - All users with balances
- **Delete Account** - Remove user (careful!)

### Ledger Tab
- **Verify Ledger Proof** - Check ledger integrity
- Ensures all debits = credits
- Detects ledger corruption
- Shows proof details in JSON

### Features Tab
- Enable/disable features (extend as needed)
- Maintenance mode toggle
- Rate limiting controls
- Future: 2FA, sanctions list, etc.

## 🔧 Customization

### Add New API Endpoint

Edit `admin-server.js` and add to the `routes` object:

```javascript
"GET /api/custom": async (req, res, token) => {
  // Your logic here
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ data: "value" }));
},
```

### Style Changes

Dashboard HTML is in `getDashboardHTML()`. Modify CSS variables:

```css
--primary: #3b82f6;    /* Blue */
--danger: #ef4444;     /* Red */
--success: #10b981;    /* Green */
--bg-dark: #0f172a;    /* Background */
```

### Extend Features Tab

Add HTML & JavaScript to show toggles for:
- Maintenance mode
- Rate limiting
- 2FA enforcement
- Transaction limits
- etc.

## 🔐 Security

### DO:
- ✅ Change `ADMIN_PASSWORD` from default
- ✅ Use HTTPS in production (Railway/Render provide this)
- ✅ Keep `BACKEND_URL` secret
- ✅ Log admin actions
- ✅ Rotate passwords regularly
- ✅ Monitor for unusual access patterns

### DON'T:
- ❌ Commit `.env` to git
- ❌ Use weak passwords
- ❌ Share admin credentials
- ❌ Allow public access without 2FA
- ❌ Log sensitive data
- ❌ Delete accounts without backup

## 📊 API Reference

The admin dashboard calls these endpoints on your backend:

```
GET  /api/ledger           Get all accounts & data
GET  /api/ledger/proof     Verify ledger integrity
POST /api/accounts         Create new account
GET  /api/accounts         List all accounts
DELETE /api/accounts/{id}  Delete account
```

Make sure your backend implements these or update the dashboard routes.

## 🐛 Troubleshooting

**"Cannot connect to backend"**
- Verify `BACKEND_URL` is correct
- Check backend is running: `curl $BACKEND_URL/api/ledger`
- Check CORS headers

**"Invalid password"**
- Verify `ADMIN_PASSWORD` env var
- Default is `changeme123`

**"Dashboard is blank"**
- Check browser console (F12) for errors
- Clear localStorage: `localStorage.clear()`
- Reload page

**"Transaction/Account data not showing"**
- Check backend is returning data
- Verify API endpoints exist
- Check browser Network tab for errors

## 📈 Production Checklist

- [ ] Change admin password
- [ ] Set BACKEND_URL to production backend
- [ ] Enable HTTPS (should be automatic)
- [ ] Set up backups
- [ ] Enable audit logging
- [ ] Monitor error logs
- [ ] Add rate limiting to `/api/login`
- [ ] Consider adding 2FA
- [ ] Document admin procedures
- [ ] Test disaster recovery

## 🚀 Deployment URLs

After deployment, your dashboard will be at:

**Railway:** `https://zarpay-admin-[random].railway.app`  
**Render:** `https://zarpay-admin.onrender.com`  
**Local:** `http://localhost:3000`

## 📞 Support

- [Full deployment guide](./DEPLOYMENT.md)
- [Railway docs](https://railway.app/docs)
- [Render docs](https://render.com/docs)

---

**Made for Zarpay Pakistan 🇵🇰**

Start with local testing, then deploy to Railway or Render for your production admin panel.
