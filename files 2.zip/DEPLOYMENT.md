# Zarpay Admin Dashboard - Deployment Guide

## 🚀 Quick Start (Local)

```bash
# Install (no dependencies!)
npm install

# Run the admin dashboard
node admin-server.js
```

Visit: **http://localhost:3000**  
Default password: **changeme123** (change this!)

---

## 📦 Deploy to Railway.app

### Step 1: Connect Your GitHub Repo
1. Push the `admin-server.js` and `package.json` to your GitHub repo
2. Go to [railway.app](https://railway.app)
3. Click **"New Project"** → **"Deploy from GitHub Repo"**
4. Select your repo and authorize

### Step 2: Set Environment Variables
In Railway dashboard, go to **Variables** and add:

```
ADMIN_PASSWORD=your_secure_password_here
BACKEND_URL=https://your-zarpay-backend.railway.app
PORT=3000
```

### Step 3: Deploy
Railway auto-deploys on push. Your dashboard is live!

**Your URL will be:** `https://zarpay-admin-[random].railway.app`

---

## 🎯 Deploy to Render.com

### Step 1: Create a New Web Service
1. Go to [render.com](https://render.com)
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub repo

### Step 2: Configure
- **Name:** `zarpay-admin`
- **Environment:** `Node`
- **Build Command:** `npm install`
- **Start Command:** `node admin-server.js`
- **Plan:** Free tier works great

### Step 3: Set Environment Variables
Under **Environment**, add:

```
ADMIN_PASSWORD=your_secure_password_here
BACKEND_URL=https://your-zarpay-backend.onrender.com
```

### Step 4: Deploy
Click **"Deploy"** and Render builds & runs your dashboard.

**Your URL will be:** `https://zarpay-admin.onrender.com`

---

## 🔐 Security Checklist

- [ ] Change `ADMIN_PASSWORD` from default (`changeme123`)
- [ ] Use HTTPS (Railway & Render provide this)
- [ ] Set `BACKEND_URL` to your production backend
- [ ] Add IP whitelisting if possible
- [ ] Rotate the admin password regularly
- [ ] Monitor logs for suspicious activity

---

## 📊 Dashboard Features

### Dashboard Tab
- **Total Accounts:** Number of users in the system
- **Total Transactions:** Count of all transactions
- **Total Volume:** Sum of all account balances
- **System Health:** Backend status

### Transactions Tab
- Real-time transaction history
- View sender, receiver, amount, timestamp
- Sort and filter by date

### Accounts Tab
- Manage user accounts
- **Add Account:** Create new user with initial balance
- **Delete Account:** Remove accounts (use carefully!)
- View account balances and status

### Ledger Tab
- **Verify Ledger Proof:** Check double-entry ledger integrity
- Ensures debits = credits across all accounts
- Detects ledger corruption

### Features Tab
- Enable/disable app features
- Maintenance mode toggle
- Rate limiting controls

---

## 🔧 Backend Integration

The dashboard makes API calls to your Zarpay backend at:

```
GET  /api/ledger           → Account data
GET  /api/ledger/proof     → Ledger verification
POST /api/accounts         → Create account
POST /api/transactions     → View transactions
```

Make sure your `BACKEND_URL` matches your actual backend endpoint.

---

## 📝 Environment Variables Reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ADMIN_PASSWORD` | Yes | `changeme123` | Login password |
| `BACKEND_URL` | Yes | `http://localhost:4000` | Zarpay backend API |
| `PORT` | No | `3000` | Server port |

---

## 🐛 Troubleshooting

### "Cannot connect to backend"
- Check `BACKEND_URL` is correct
- Verify backend is running and accessible
- Check CORS headers on backend

### "Invalid password"
- Verify `ADMIN_PASSWORD` environment variable
- Default is `changeme123`

### "504 Gateway Timeout"
- Backend is too slow or down
- Check backend logs
- Increase timeout in `admin-server.js` if needed

### "Blank dashboard"
- Check browser console for JavaScript errors
- Verify authentication token in localStorage
- Try clearing cache and reloading

---

## 📈 Production Tips

1. **Use a database for sessions** instead of in-memory storage
2. **Add rate limiting** to prevent brute force
3. **Log all admin actions** for audit trail
4. **Set up alerts** for unusual activity
5. **Use 2FA** for admin login if possible
6. **Backup ledger regularly** from dashboard

---

## 📞 Support

For issues:
1. Check the logs: `railway logs` or Render dashboard
2. Verify environment variables are set
3. Test backend connectivity: `curl $BACKEND_URL/api/ledger`
4. Check browser console for errors
